Create Table Fbusers
( UserId int NOT NULL Primary key, Firstname varchar (45),
 Lastname varchar (45),
 Gender varchar (45),
 Hometown varchar (150), 
 city varchar (45));
 
  create Table Fbfriends
  ( UserId int, 
  Friend_ID int,
  Primary key (UserID,Friend_ID),
  Foreign Key (UserID) References Fbusers (UserId),
  Foreign Key (Friend_ID) References Fbusers (UserId));
   SELECT * FROM fbfriends
  ORDER BY UserId asc;

  create Table Messages
  (sender_ID int,
  Receiver_ID int,
  Date_Time datetime,
  Messages varchar (150),
  Primary key (Sender_Id,Receiver_Id,Date_Time,Messages),
  Foreign Key (Sender_Id) References Fbusers (UserId),
  Foreign Key (Receiver_Id) References Fbusers (UserId));
  SELECT * FROM messages
  ORDER BY sender_id asc;
  
create table Universities
  (Student_Id int NOT NULL, 
  University varchar (155) NOT NULL,
  Primary key (Student_Id, University) ,
  Foreign key (Student_Id) References Fbusers (UserId));
  
  SELECT Universities.Student_Id,universities.University, fbusers.Firstname, fbusers.LastName
FROM ((universities
INNER JOIN fbusers ON Universities.Student_Id = fbusers.UserId));
  
  create Table Workplace
  (UserId int NOT NULL, 
  Workplace varchar (45) NOT NULL,
  Primary key (UserId, Workplace),
  Foreign key (UserId) References Fbusers (UserId));
  
  SELECT Workplace.UserId,Workplace.workplace, fbusers.Firstname, fbusers.LastName
FROM ((Workplace
INNER JOIN fbusers ON Workplace.UserId = fbusers.UserId));




  
  
  
  









  select*from fbfriends;
  Select*from fbusers;
  select*from messages;
  select*from universities;
  select*from workplace;
  
  
  
  

  
  

  
 
 
 
 